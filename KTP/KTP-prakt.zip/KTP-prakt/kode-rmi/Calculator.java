public class Calculator implements ICalculator{
	public double add(double number1, double number2){
		return number1+number2;
	}
}